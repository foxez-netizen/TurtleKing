/* 느릿느릿 사주풀이 — 만세력 계산 엔진
 * 사주 네 기둥(년·월·일·시), 지장간, 십성, 십이운성, 오행 세력, 합충형해, 신살, 대운·세운을 계산합니다.
 * 계산 기준은 /saju/method.html 에 공개되어 있습니다. */
(function (global) {
  "use strict";
  var D = global.SAJU_DATA;

  var STEMS = ["갑", "을", "병", "정", "무", "기", "경", "신", "임", "계"];
  var STEMS_H = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"];
  var BRANCHES = ["자", "축", "인", "묘", "진", "사", "오", "미", "신", "유", "술", "해"];
  var BRANCHES_H = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"];
  var ANIMALS = ["쥐", "소", "호랑이", "토끼", "용", "뱀", "말", "양", "원숭이", "닭", "개", "돼지"];
  var EL = ["목", "화", "토", "금", "수"];
  var EL_H = ["木", "火", "土", "金", "水"];
  var STEM_EL = [0, 0, 1, 1, 2, 2, 3, 3, 4, 4];
  var STEM_YANG = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0];
  var BRANCH_EL = [4, 2, 0, 0, 2, 1, 1, 2, 3, 3, 2, 4];
  // 지지의 음양(체 기준): 자인묘... 십성 계산에는 본기 천간의 음양을 사용
  var BRANCH_YANG = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0];

  // 지장간: [천간 인덱스, 일수] — 여기 → 중기 → 본기 순
  var HIDDEN = [
    [[8, 10], [9, 20]],                 // 자
    [[9, 9], [7, 3], [5, 18]],          // 축
    [[4, 7], [2, 7], [0, 16]],          // 인
    [[0, 10], [1, 20]],                 // 묘
    [[1, 9], [9, 3], [4, 18]],          // 진
    [[4, 7], [6, 7], [2, 16]],          // 사
    [[2, 10], [5, 9], [3, 11]],         // 오
    [[3, 9], [1, 3], [5, 18]],          // 미
    [[4, 7], [8, 7], [6, 16]],          // 신
    [[6, 10], [7, 20]],                 // 유
    [[7, 9], [3, 3], [4, 18]],          // 술
    [[4, 7], [0, 7], [8, 16]]           // 해
  ];
  function mainStemOf(b) { var h = HIDDEN[b]; return h[h.length - 1][0]; }

  var TEN_GODS = ["비견", "겁재", "식신", "상관", "편재", "정재", "편관", "정관", "편인", "정인"];
  var TEN_GROUP = ["비겁", "비겁", "식상", "식상", "재성", "재성", "관성", "관성", "인성", "인성"];
  var STAGES = ["장생", "목욕", "관대", "건록", "제왕", "쇠", "병", "사", "묘", "절", "태", "양"];
  var STAGE_START = [11, 6, 2, 9, 2, 9, 5, 0, 8, 3]; // 갑 해, 을 오, 병 인, 정 유, 무 인, 기 유, 경 사, 신 자, 임 신, 계 묘

  function mod(a, n) { return ((a % n) + n) % n; }

  /* ---------- 십성 ---------- */
  function tenGod(dayStem, other) {
    var de = STEM_EL[dayStem], oe = STEM_EL[other];
    var same = STEM_YANG[dayStem] === STEM_YANG[other];
    var rel = mod(oe - de, 5); // 0 같음, 1 내가 생함, 2 내가 극함, 3 나를 극함, 4 나를 생함
    var base = [0, 2, 4, 6, 8][rel];
    return base + (same ? 0 : 1);
  }
  function stage(dayStem, branch) {
    var s = STAGE_START[dayStem];
    var i = STEM_YANG[dayStem] ? mod(branch - s, 12) : mod(s - branch, 12);
    return i;
  }

  /* ---------- 날짜 도우미 ---------- */
  function dayNumber(y, m, d) { return Math.round(Date.UTC(y, m - 1, d) / 86400000); }
  var EPOCH_1900 = dayNumber(1900, 1, 1);
  function dayPillarIdx(y, m, d) { return mod(dayNumber(y, m, d) - EPOCH_1900 + 10, 60); }
  function pillarIdx(stem, branch) {
    for (var i = 0; i < 60; i++) if (i % 10 === stem && i % 12 === branch) return i;
    return 0;
  }
  function idxToPillar(i) { i = mod(i, 60); return { stem: i % 10, branch: i % 12 }; }

  /* ---------- 한국 표준시 이력 (분 단위 오프셋) ---------- */
  function ymdNum(y, m, d) { return y * 10000 + m * 100 + d; }
  function baseOffset(y, m, d) {
    var n = ymdNum(y, m, d);
    if (n < 19080401) return 508;       // 한양 지방평균시(약 +8:28)
    if (n < 19120101) return 510;       // +8:30
    if (n < 19540321) return 540;       // +9:00
    if (n < 19610810) return 510;       // +8:30
    return 540;
  }
  var DST = [ // [시작, 끝] 포함, 현지 날짜
    [19480601, 19480912], [19490403, 19490910], [19500401, 19500909], [19510506, 19510908],
    [19550505, 19550908], [19560520, 19560929], [19570505, 19570921], [19580504, 19580920],
    [19590503, 19590919], [19600501, 19600917], [19870510, 19871010], [19880508, 19881008]
  ];
  function isDst(y, m, d) {
    var n = ymdNum(y, m, d);
    for (var i = 0; i < DST.length; i++) if (n >= DST[i][0] && n <= DST[i][1]) return true;
    return false;
  }

  /* ---------- 절기 ---------- */
  // 12절: 소한 입춘 경칩 청명 입하 망종 소서 입추 백로 한로 입동 대설 → 월지 축 인 묘 진 사 오 미 신 유 술 해 자
  var JIE_BRANCH = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 0];
  var JIE_NAMES = ["소한", "입춘", "경칩", "청명", "입하", "망종", "소서", "입추", "백로", "한로", "입동", "대설"];
  function termUtcMs(year, i) {
    var row = D.terms[year - D.termStartYear];
    return Date.UTC(year, 0, 1) - 9 * 3600000 + row[i] * 60000;
  }
  function jieList(year) {
    var out = [];
    for (var y = year - 1; y <= year + 1; y++) {
      if (y < D.termStartYear || y > D.termStartYear + D.terms.length - 1) continue;
      for (var i = 0; i < 12; i++) out.push({ t: termUtcMs(y, i), idx: i, year: y, branch: JIE_BRANCH[i], name: JIE_NAMES[i] });
    }
    return out;
  }
  function fmtKst(ms) {
    var d = new Date(ms + 9 * 3600000);
    return d.getUTCFullYear() + "." + pad(d.getUTCMonth() + 1) + "." + pad(d.getUTCDate()) + " " + pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes());
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }

  /* ---------- 음력 ---------- */
  function lunarMonths(ly) {
    var v = D.lunar[ly]; if (!v) return null;
    var list = [], n = v[3];
    var leapM = v[1];
    for (var i = 0; i < n; i++) {
      list.push({ lm: 0, leap: false, len: (v[2] >> i) & 1 ? 30 : 29 });
    }
    // 월 번호 부여: 1,2,...,leapM,(윤leapM),leapM+1,...
    var m = 1, i2 = 0;
    while (i2 < n) {
      list[i2].lm = m; list[i2].leap = false; i2++;
      if (leapM && m === leapM && i2 < n) { list[i2].lm = m; list[i2].leap = true; i2++; }
      m++;
    }
    return list;
  }
  function lunarToSolar(ly, lm, leap, ld) {
    if (!D.lunar[ly]) return null;
    var months = lunarMonths(ly), off = D.lunar[ly][0];
    for (var i = 0; i < months.length; i++) {
      var mo = months[i];
      if (mo.lm === lm && mo.leap === !!leap) {
        if (ld < 1 || ld > mo.len) return null;
        var dn = EPOCH_1900 + off + ld - 1;
        var dt = new Date(dn * 86400000);
        return { y: dt.getUTCFullYear(), m: dt.getUTCMonth() + 1, d: dt.getUTCDate() };
      }
      off += mo.len;
    }
    return null;
  }
  function solarToLunar(y, m, d) {
    var dn = dayNumber(y, m, d) - EPOCH_1900;
    for (var yy = Math.min(y, D.lunarEnd); yy >= D.lunarStart; yy--) {
      var v = D.lunar[yy]; if (!v) continue;
      if (dn >= v[0]) {
        var months = lunarMonths(yy), off = v[0];
        for (var i = 0; i < months.length; i++) {
          if (dn < off + months[i].len) return { y: yy, m: months[i].lm, leap: months[i].leap, d: dn - off + 1 };
          off += months[i].len;
        }
      }
    }
    return null;
  }
  function lunarMonthLen(ly, lm, leap) {
    var ms = lunarMonths(ly); if (!ms) return 30;
    for (var i = 0; i < ms.length; i++) if (ms[i].lm === lm && ms[i].leap === !!leap) return ms[i].len;
    return 0;
  }
  function hasLeap(ly, lm) { var v = D.lunar[ly]; return !!v && v[1] === lm; }

  /* ---------- 사주 계산 ---------- */
  /**
   * opts: { y,m,d, hour (0-23|null), minute, calendar:"solar"|"lunar", leap:boolean,
   *         gender:"M"|"F", jaSi:"jo"|"ya", correction:boolean, dst:boolean }
   */
  function calcPillars(opts) {
    var y = opts.y, m = opts.m, d = opts.d;
    var hasTime = opts.hour !== null && opts.hour !== undefined && opts.hour !== "";
    var hour = hasTime ? +opts.hour : 12, minute = hasTime ? (+opts.minute || 0) : 0;
    var lunarInfo = null;
    if (opts.calendar === "lunar") {
      var s = lunarToSolar(y, m, opts.leap, d);
      if (!s) throw new Error("입력한 음력 날짜를 찾을 수 없습니다. 월·일·윤달 여부를 확인해 주세요.");
      lunarInfo = { y: y, m: m, d: d, leap: !!opts.leap };
      y = s.y; m = s.m; d = s.d;
    } else {
      var l = solarToLunar(y, m, d);
      if (l) lunarInfo = l;
    }
    if (dayNumber(y, m, d) < dayNumber(1900, 2, 1) || dayNumber(y, m, d) > dayNumber(2100, 11, 30)) throw new Error("1900년 2월 1일부터 2100년 11월 30일까지 지원합니다.");

    // 현지 시계 → 표준시 시계
    var clock = Date.UTC(y, m - 1, d, hour, minute); // "벽시계 숫자"로 취급
    var dstOn = (opts.dst !== false) && isDst(y, m, d);
    var base = baseOffset(y, m, d);
    var stdClock = clock - (dstOn ? 60 : 0) * 60000;
    var corrected = false;
    if (opts.correction && base === 540) { stdClock -= 30 * 60000; corrected = true; }
    var instant = stdClock - base * 60000; // UTC ms (절기와 비교)

    var cd = new Date(stdClock);
    var cy = cd.getUTCFullYear(), cm = cd.getUTCMonth() + 1, cdd = cd.getUTCDate();
    var ch = cd.getUTCHours(), cmin = cd.getUTCMinutes();

    // 절기 경계
    var list = jieList(cy);
    var prev = null, next = null;
    for (var i = 0; i < list.length; i++) {
      if (list[i].t <= instant) prev = list[i]; else { next = list[i]; break; }
    }
    // 년주: 입춘 기준
    var lichunThis = termUtcMs(cy, 1);
    var sy = instant < lichunThis ? cy - 1 : cy;
    if (cy === D.termStartYear && instant < lichunThis) sy = cy - 1;
    var yearStem = mod(sy - 4, 10), yearBranch = mod(sy - 4, 12);
    // 월주
    var monthBranch = prev.branch;
    var inStart = [2, 4, 6, 8, 0][yearStem % 5]; // 갑기→병, 을경→무, 병신→경, 정임→임, 무계→갑 (인월 천간)
    var monthStem = mod(inStart + mod(monthBranch - 2, 12), 10);
    // 일주 (자시 처리)
    var dayDate = { y: cy, m: cm, d: cdd };
    var lateZa = hasTime && ch === 23;
    var dayShift = (lateZa && opts.jaSi !== "ya") ? 1 : 0;
    var dd = new Date(Date.UTC(cy, cm - 1, cdd + dayShift));
    var dayIdx = dayPillarIdx(dd.getUTCFullYear(), dd.getUTCMonth() + 1, dd.getUTCDate());
    var dayP = idxToPillar(dayIdx);
    // 시주
    var hourP = null;
    if (hasTime) {
      var hb = Math.floor(((ch * 60 + cmin) + 60) / 120) % 12;
      var startStem = [0, 2, 4, 6, 8][dayP.stem % 5];
      hourP = { stem: mod(startStem + hb, 10), branch: hb };
    }
    var pillars = {
      year: { stem: yearStem, branch: yearBranch },
      month: { stem: monthStem, branch: monthBranch },
      day: dayP,
      hour: hourP
    };

    // 대운 방향/시작
    var forward = (STEM_YANG[yearStem] === 1) === (opts.gender === "M");
    var diffMs = forward ? (next.t - instant) : (instant - prev.t);
    var years = diffMs / 86400000 / 3;
    var startAge = Math.max(1, Math.round(years));
    var monthIdx = pillarIdx(monthStem, monthBranch);
    var dw = [];
    var startInstant = instant + years * 365.2422 * 86400000;
    for (var k = 1; k <= 10; k++) {
      var p = idxToPillar(monthIdx + (forward ? k : -k));
      var startMs = startInstant + (k - 1) * 10 * 365.2422 * 86400000;
      dw.push({ stem: p.stem, branch: p.branch, age: startAge + (k - 1) * 10, year: new Date(startMs + 9 * 3600000).getUTCFullYear() });
    }

    var res = {
      input: { y: y, m: m, d: d, hour: hasTime ? hour : null, minute: minute, gender: opts.gender, calendar: opts.calendar, leap: !!opts.leap },
      solar: { y: y, m: m, d: d }, lunar: lunarInfo,
      pillars: pillars, hasTime: hasTime,
      meta: {
        dstApplied: dstOn, corrected: corrected, baseOffset: base,
        usedClock: pad(ch) + ":" + pad(cmin), usedDate: cy + "." + pad(cm) + "." + pad(cdd),
        prevJie: { name: prev.name, at: fmtKst(prev.t) }, nextJie: { name: next.name, at: fmtKst(next.t) },
        lateZa: lateZa, jaSi: opts.jaSi || "jo", birthYearForPillar: sy,
        nearTerm: Math.min(instant - prev.t, next.t - instant) < 36 * 3600000 ? (instant - prev.t < next.t - instant ? prev : next) : null,
        nearTermMinutes: Math.round(Math.min(instant - prev.t, next.t - instant) / 60000)
      },
      luck: { forward: forward, startAge: startAge, exactYears: years, list: dw, birthYear: y }
    };
    return analyze(res);
  }

  /* ---------- 분석 ---------- */
  var KEYS = ["hour", "day", "month", "year"];
  var TRIPLES = [[2, 6, 10], [8, 0, 4], [5, 9, 1], [11, 3, 7]]; // 인오술 신자진 사유축 해묘미
  var TRIPLE_INFO = [
    { set: [2, 6, 10], el: 1 }, { set: [8, 0, 4], el: 4 }, { set: [5, 9, 1], el: 3 }, { set: [11, 3, 7], el: 0 }
  ];

  function analyze(r) {
    var P = r.pillars, ds = P.day.stem;
    var cols = {};
    KEYS.forEach(function (k) {
      var p = P[k];
      if (!p) { cols[k] = null; return; }
      var hidden = HIDDEN[p.branch].map(function (h) { return { stem: h[0], days: h[1], god: tenGod(ds, h[0]) }; });
      cols[k] = {
        stem: p.stem, branch: p.branch,
        stemGod: k === "day" ? -1 : tenGod(ds, p.stem),
        branchGod: tenGod(ds, mainStemOf(p.branch)),
        hidden: hidden,
        stage: stage(ds, p.branch),
        stemEl: STEM_EL[p.stem], branchEl: BRANCH_EL[p.branch]
      };
    });
    r.cols = cols;

    // 오행 세력 (천간 1점, 지지는 지장간 일수 비율로 1점 분배, 월지 ×1.5) + 십성 그룹 점수
    var elScore = [0, 0, 0, 0, 0], godScore = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], eight = [0, 0, 0, 0, 0];
    KEYS.forEach(function (k) {
      var c = cols[k]; if (!c) return;
      elScore[c.stemEl] += 1; godScore[k === "day" ? 0 : c.stemGod] += (k === "day" ? 0 : 1);
      eight[c.stemEl]++; eight[c.branchEl]++;
      var w = k === "month" ? 1.5 : 1;
      c.hidden.forEach(function (h) {
        var portion = h.days / 30 * w;
        elScore[STEM_EL[h.stem]] += portion;
        godScore[h.god] += portion;
      });
    });
    var total = elScore.reduce(function (a, b) { return a + b; }, 0);
    r.elements = EL.map(function (n, i) { return { idx: i, name: n, hanja: EL_H[i], score: elScore[i], pct: total ? elScore[i] / total * 100 : 0, count8: eight[i] }; });
    r.godScore = godScore;
    var groups = { 비겁: 0, 식상: 0, 재성: 0, 관성: 0, 인성: 0 };
    for (var g = 0; g < 10; g++) groups[TEN_GROUP[g]] += godScore[g];
    var gTotal = 0; for (var kk in groups) gTotal += groups[kk];
    r.groups = Object.keys(groups).map(function (n) { return { name: n, score: groups[n], pct: gTotal ? groups[n] / gTotal * 100 : 0 }; });

    // 신강/신약 (참고): (비겁+인성) 비율 + 득령·득지·득세
    var self = groups["비겁"] + groups["인성"];
    var ratio = gTotal ? self / gTotal : 0.5;
    var monthMain = tenGod(ds, mainStemOf(P.month.branch));
    var dayMain = tenGod(ds, mainStemOf(P.day.branch));
    var helps = function (g) { return TEN_GROUP[g] === "비겁" || TEN_GROUP[g] === "인성"; };
    var deukRyeong = helps(monthMain), deukJi = helps(dayMain), cnt = 0, others = 0;
    KEYS.forEach(function (k) {
      var c = cols[k]; if (!c) return;
      if (k !== "day") { others++; if (helps(c.stemGod)) cnt++; }
      if (k !== "month" && k !== "day") { others++; if (helps(c.branchGod)) cnt++; }
    });
    var deukSe = cnt >= Math.ceil(others / 2);
    var label;
    if (ratio >= 0.6) label = "신강"; else if (ratio >= 0.5) label = "약간 신강"; else if (ratio >= 0.4) label = "약간 신약"; else label = "신약";
    r.strength = { ratio: ratio, label: label, deukRyeong: deukRyeong, deukJi: deukJi, deukSe: deukSe };

    // 균형을 맞춰주는 기운 (억부 + 조후 단순화, 참고용)
    var de = STEM_EL[ds];
    var rel = { me: de, out: (de + 1) % 5, wealth: (de + 2) % 5, power: (de + 3) % 5, resource: (de + 4) % 5 };
    var helpers = [];
    var season = [4, 4, 0, 0, 2, 1, 1, 2, 3, 3, 2, 4][P.month.branch]; // 월지 오행
    var mb = P.month.branch;
    var needNote = "";
    if ([5, 6, 7].indexOf(mb) >= 0 && r.elements[4].pct < 12) { helpers.push(4); needNote = "한여름에 태어나 열기가 강해, 식혀 주는 수(水)의 기운이 도움이 됩니다."; }
    else if ([11, 0, 1].indexOf(mb) >= 0 && r.elements[1].pct < 12) { helpers.push(1); needNote = "한겨울에 태어나 차가운 기운이 강해, 데워 주는 화(火)의 기운이 도움이 됩니다."; }
    if (ratio >= 0.5) { [rel.wealth, rel.power, rel.out].forEach(function (e) { if (helpers.indexOf(e) < 0) helpers.push(e); }); }
    else { [rel.resource, rel.me].forEach(function (e) { if (helpers.indexOf(e) < 0) helpers.push(e); }); }
    r.helpers = { elements: helpers.slice(0, 3), note: needNote, season: season };

    // 합·충·형·해
    r.relations = relations(r);
    // 신살
    r.sinsal = sinsal(r);
    // 공망
    var xunStart = mod(P.day.branch - P.day.stem, 12);
    r.gongmang = [mod(xunStart + 10, 12), mod(xunStart + 11, 12)];
    // 대운 십성
    r.luck.list.forEach(function (l) { l.stemGod = tenGod(ds, l.stem); l.branchGod = tenGod(ds, mainStemOf(l.branch)); l.stage = stage(ds, l.branch); });
    return r;
  }

  var POS = { year: "년", month: "월", day: "일", hour: "시" };
  function relations(r) {
    var out = [], P = r.pillars, keys = KEYS.filter(function (k) { return P[k]; });
    var HAP_S = { "0,5": 2, "1,6": 3, "2,7": 4, "3,8": 0, "4,9": 1 };
    var CHUNG_S = ["0,6", "1,7", "2,8", "3,9"];
    var YUKHAP = { "0,1": 2, "2,11": 0, "3,10": 1, "4,9": 3, "5,8": 4, "6,7": null };
    var CHUNG_B = ["0,6", "1,7", "2,8", "3,9", "4,10", "5,11"];
    var HAE = ["0,7", "1,6", "2,5", "3,4", "8,11", "9,10"];
    var HYUNG2 = ["0,3"];
    for (var i = 0; i < keys.length; i++) {
      for (var j = i + 1; j < keys.length; j++) {
        var a = P[keys[i]], b = P[keys[j]];
        var where = POS[keys[i]] + "·" + POS[keys[j]];
        var sk = [Math.min(a.stem, b.stem), Math.max(a.stem, b.stem)].join(",");
        if (HAP_S[sk] !== undefined) out.push({ type: "천간합", text: where + "간 " + STEMS[a.stem] + STEMS[b.stem] + "합(" + EL[HAP_S[sk]] + ")", pair: [keys[i], keys[j]], el: HAP_S[sk] });
        if (CHUNG_S.indexOf(sk) >= 0) out.push({ type: "천간충", text: where + "간 " + STEMS[a.stem] + STEMS[b.stem] + "충", pair: [keys[i], keys[j]] });
        var bk = [Math.min(a.branch, b.branch), Math.max(a.branch, b.branch)].join(",");
        if (YUKHAP.hasOwnProperty(bk)) out.push({ type: "지지육합", text: where + "지 " + BRANCHES[a.branch] + BRANCHES[b.branch] + "합" + (YUKHAP[bk] !== null ? "(" + EL[YUKHAP[bk]] + ")" : "(화)"), pair: [keys[i], keys[j]] });
        if (CHUNG_B.indexOf(bk) >= 0) out.push({ type: "지지충", text: where + "지 " + BRANCHES[a.branch] + BRANCHES[b.branch] + "충", pair: [keys[i], keys[j]] });
        if (HAE.indexOf(bk) >= 0) out.push({ type: "지지해", text: where + "지 " + BRANCHES[a.branch] + BRANCHES[b.branch] + "해", pair: [keys[i], keys[j]] });
        if (HYUNG2.indexOf(bk) >= 0) out.push({ type: "지지형", text: where + "지 " + BRANCHES[a.branch] + BRANCHES[b.branch] + "형(무례지형)", pair: [keys[i], keys[j]] });
        if (a.branch === b.branch && [4, 6, 9, 11].indexOf(a.branch) >= 0) out.push({ type: "지지형", text: where + "지 " + BRANCHES[a.branch] + BRANCHES[b.branch] + " 자형", pair: [keys[i], keys[j]] });
      }
    }
    var bs = keys.map(function (k) { return P[k].branch; });
    TRIPLE_INFO.forEach(function (t) {
      var n = t.set.filter(function (x) { return bs.indexOf(x) >= 0; }).length;
      if (n === 3) out.push({ type: "삼합", text: t.set.map(function (x) { return BRANCHES[x]; }).join("") + " 삼합(" + EL[t.el] + "국)", el: t.el });
      else if (n === 2) {
        // 반합: 중심 글자(제왕지)를 포함할 때만
        var center = t.set[1];
        if (bs.indexOf(center) >= 0) out.push({ type: "반합", text: t.set.filter(function (x) { return bs.indexOf(x) >= 0; }).map(function (x) { return BRANCHES[x]; }).join("") + " 반합(" + EL[t.el] + ")", el: t.el });
      }
    });
    [[2, 5, 8], [1, 10, 7]].forEach(function (set) {
      var n = set.filter(function (x) { return bs.indexOf(x) >= 0; }).length;
      if (n === 3) out.push({ type: "지지형", text: set.map(function (x) { return BRANCHES[x]; }).join("") + " 삼형" });
    });
    return out;
  }

  function sinsal(r) {
    var P = r.pillars, ds = P.day.stem, yb = P.year.branch, db = P.day.branch;
    var out = [], keys = KEYS.filter(function (k) { return P[k]; });
    function add(name, key, where) { out.push({ name: name, where: where }); }
    function posList(branches, filterFn) {
      return keys.filter(function (k) { return branches.indexOf(P[k].branch) >= 0 && (!filterFn || filterFn(k)); });
    }
    // 천을귀인
    var GUIIN = { 0: [1, 7], 4: [1, 7], 6: [1, 7], 1: [0, 8], 5: [0, 8], 2: [11, 9], 3: [11, 9], 8: [5, 3], 9: [5, 3], 7: [2, 6] };
    var gset = GUIIN[ds];
    var gp = posList(gset, function (k) { return k !== "day" || true; });
    if (gp.length) out.push({ name: "천을귀인", where: gp.map(function (k) { return POS[k] + "지(" + BRANCHES[P[k].branch] + ")"; }) });
    // 문창귀인
    var MUNCHANG = [5, 6, 8, 9, 8, 9, 11, 0, 2, 3];
    var mp = posList([MUNCHANG[ds]]);
    if (mp.length) out.push({ name: "문창귀인", where: mp.map(function (k) { return POS[k] + "지(" + BRANCHES[P[k].branch] + ")"; }) });
    // 삼합 기준 신살 (일지·년지)
    function tri(b) { for (var i = 0; i < 4; i++) if (TRIPLES[i].indexOf(b) >= 0) return i; return 0; }
    // 인오술→묘 신자진→유 사유축→오 해묘미→자 (TRIPLES 순서: 인오술, 신자진, 사유축, 해묘미)
    var DOHWA = [3, 9, 6, 0], YEOKMA = [8, 2, 11, 5], HWAGAE = [10, 4, 1, 7], GEOBSAL = [11, 5, 2, 8], MANGSIN = [5, 11, 8, 2];
    function byTri(name, table, kind) {
      var hits = [];
      [["day", db], ["year", yb]].forEach(function (pair) {
        var target = table[tri(pair[1])];
        keys.forEach(function (k) {
          if (k === pair[0]) return;
          if (P[k].branch === target) {
            var label = POS[k] + "지(" + BRANCHES[target] + ") · " + POS[pair[0]] + "지 기준";
            if (hits.indexOf(label) < 0) hits.push(label);
          }
        });
      });
      if (hits.length) out.push({ name: name, where: hits });
    }
    byTri("도화살", DOHWA); byTri("역마살", YEOKMA); byTri("화개살", HWAGAE);
    // 양인살 (양간)
    var YANGIN = { 0: 3, 2: 6, 4: 6, 6: 9, 8: 0 };
    if (YANGIN[ds] !== undefined) {
      var yp = posList([YANGIN[ds]]);
      if (yp.length) out.push({ name: "양인살", where: yp.map(function (k) { return POS[k] + "지(" + BRANCHES[P[k].branch] + ")"; }) });
    }
    // 일주 기준: 괴강, 백호대살
    var di = pillarIdx(P.day.stem, P.day.branch);
    var gwegang = [pillarIdx(6, 4), pillarIdx(6, 10), pillarIdx(8, 4), pillarIdx(4, 10)];
    if (gwegang.indexOf(di) >= 0) out.push({ name: "괴강살", where: ["일주(" + STEMS[P.day.stem] + BRANCHES[P.day.branch] + ")"] });
    var BAEKHO = [[0, 4], [1, 7], [2, 10], [3, 1], [4, 4], [8, 10], [9, 1]];
    keys.forEach(function (k) {
      BAEKHO.forEach(function (bh) {
        if (P[k].stem === bh[0] && P[k].branch === bh[1]) out.push({ name: "백호대살", where: [POS[k] + "주(" + STEMS[bh[0]] + BRANCHES[bh[1]] + ")"] });
      });
    });
    // 귀문관살, 원진살 (지지 쌍)
    var GWIMUN = ["0,9", "1,6", "2,7", "3,8", "4,11", "5,10"];
    var WONJIN = ["0,7", "1,6", "2,9", "3,8", "4,11", "5,10"];
    var gm = [], wj = [];
    for (var i = 0; i < keys.length; i++) for (var j = i + 1; j < keys.length; j++) {
      var a = P[keys[i]].branch, b = P[keys[j]].branch, key = Math.min(a, b) + "," + Math.max(a, b);
      var lab = POS[keys[i]] + "·" + POS[keys[j]] + "지(" + BRANCHES[a] + BRANCHES[b] + ")";
      if (GWIMUN.indexOf(key) >= 0) gm.push(lab);
      if (WONJIN.indexOf(key) >= 0) wj.push(lab);
    }
    if (gm.length) out.push({ name: "귀문관살", where: gm });
    if (wj.length) out.push({ name: "원진살", where: wj });
    // 공망
    var xunStart = mod(P.day.branch - P.day.stem, 12), g1 = mod(xunStart + 10, 12), g2 = mod(xunStart + 11, 12);
    var gp2 = keys.filter(function (k) { return k !== "day" && (P[k].branch === g1 || P[k].branch === g2); });
    if (gp2.length) out.push({ name: "공망", where: gp2.map(function (k) { return POS[k] + "지(" + BRANCHES[P[k].branch] + ")"; }) });
    return out;
  }

  /* ---------- 세운 ---------- */
  function yearLuck(r, fromY, toY) {
    var ds = r.pillars.day.stem, out = [];
    for (var y = fromY; y <= toY; y++) {
      var s = mod(y - 4, 10), b = mod(y - 4, 12);
      out.push({ year: y, stem: s, branch: b, stemGod: tenGod(ds, s), branchGod: tenGod(ds, mainStemOf(b)), stage: stage(ds, b),
        age: y - r.solar.y + 1 });
    }
    return out;
  }

  global.Saju = {
    calc: calcPillars, yearLuck: yearLuck, lunarToSolar: lunarToSolar, solarToLunar: solarToLunar,
    lunarMonthLen: lunarMonthLen, hasLeap: hasLeap,
    tenGod: tenGod, dayPillarIdx: dayPillarIdx, pillarIdx: pillarIdx, idxToPillar: idxToPillar,
    STEMS: STEMS, STEMS_H: STEMS_H, BRANCHES: BRANCHES, BRANCHES_H: BRANCHES_H, ANIMALS: ANIMALS,
    EL: EL, EL_H: EL_H, STEM_EL: STEM_EL, STEM_YANG: STEM_YANG, BRANCH_EL: BRANCH_EL,
    TEN_GODS: TEN_GODS, TEN_GROUP: TEN_GROUP, STAGES: STAGES, HIDDEN: HIDDEN, mainStemOf: mainStemOf,
    termUtcMs: termUtcMs, jieList: jieList, fmtKst: fmtKst, isDst: isDst, baseOffset: baseOffset
  };
  if (typeof module !== "undefined" && module.exports) module.exports = global.Saju;
})(typeof window !== "undefined" ? window : globalThis);
