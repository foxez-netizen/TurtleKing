/* 느릿느릿 사주풀이 — 화면 로직 */
(function () {
  "use strict";
  var S = window.Saju, T = window.SAJU_TEXT;
  var $ = function (id) { return document.getElementById(id); };
  var KEYS = ["hour", "day", "month", "year"];
  var KEY_NAME = { hour: "시주", day: "일주", month: "월주", year: "년주" };

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function pct(n) { return (Math.round(n * 10) / 10).toFixed(1) + "%"; }
  function elc(i) { return "el-" + i; }
  function stemCell(stem, cls) {
    var e = S.STEM_EL[stem];
    return '<td class="glyph ' + elc(e) + (cls || "") + '"><span class="h">' + S.STEMS_H[stem] + '</span><span class="k">' + S.STEMS[stem] + S.EL[e] + '</span><span class="e">' + (S.STEM_YANG[stem] ? "양" : "음") + S.EL[e] + "</span></td>";
  }
  function branchCell(b, cls) {
    var e = S.BRANCH_EL[b];
    return '<td class="glyph ' + elc(e) + (cls || "") + '"><span class="h">' + S.BRANCHES_H[b] + '</span><span class="k">' + S.BRANCHES[b] + " · " + S.ANIMALS[b] + '</span><span class="e">' + S.EL[e] + "</span></td>";
  }
  function mini(stem, branch) {
    return '<span class="mini"><span class="' + elc(S.STEM_EL[stem]) + '">' + S.STEMS_H[stem] + '</span><span class="' + elc(S.BRANCH_EL[branch]) + '">' + S.BRANCHES_H[branch] + "</span></span>";
  }

  /* ---------- 폼 ---------- */
  var form = $("saju-form");
  function initForm() {
    var now = new Date();
    $("f-year").max = 2100; $("f-year").min = 1900;
    var calRadios = form.querySelectorAll('input[name="calendar"]');
    function syncCal() {
      var lunar = form.calendar.value === "lunar";
      $("leap-wrap").classList.toggle("hidden", !lunar);
    }
    calRadios.forEach(function (r) { r.addEventListener("change", syncCal); });
    $("f-notime").addEventListener("change", function () {
      var off = $("f-notime").checked;
      $("f-hour").disabled = off; $("f-min").disabled = off;
    });
    form.addEventListener("submit", function (e) { e.preventDefault(); run(true); });
    $("f-share").addEventListener("click", function () {
      var url = location.href;
      if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { toast("결과 주소를 복사했어요"); });
      else { prompt("아래 주소를 복사하세요", url); }
    });
    $("f-print").addEventListener("click", function () { window.print(); });
    // 쿼리로 복원
    var q = new URLSearchParams(location.search);
    if (q.get("y")) {
      form.calendar.value = q.get("c") === "lunar" ? "lunar" : "solar";
      $("f-year").value = q.get("y"); $("f-month").value = q.get("m"); $("f-day").value = q.get("d");
      form.gender.value = q.get("g") === "F" ? "F" : "M";
      $("f-leap").checked = q.get("leap") === "1";
      if (q.get("h") === null || q.get("h") === "") { $("f-notime").checked = true; $("f-hour").disabled = true; $("f-min").disabled = true; }
      else { $("f-hour").value = q.get("h"); $("f-min").value = q.get("mi") || 0; }
      form.jasi.value = q.get("ja") === "ya" ? "ya" : "jo";
      $("f-corr").checked = q.get("cor") === "1";
      $("f-dst").checked = q.get("dst") !== "0";
      $("f-name").value = q.get("n") || "";
      syncCal();
      run(false);
    } else { syncCal(); }
  }

  function toast(msg) {
    var t = $("toast"); t.textContent = msg; t.classList.remove("hidden");
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.add("hidden"); }, 2200);
  }

  function readOpts() {
    var noTime = $("f-notime").checked;
    return {
      calendar: form.calendar.value, leap: $("f-leap").checked && form.calendar.value === "lunar",
      y: parseInt($("f-year").value, 10), m: parseInt($("f-month").value, 10), d: parseInt($("f-day").value, 10),
      hour: noTime ? null : parseInt($("f-hour").value, 10), minute: noTime ? 0 : (parseInt($("f-min").value, 10) || 0),
      gender: form.gender.value, jaSi: form.jasi.value, correction: $("f-corr").checked, dst: $("f-dst").checked,
      name: $("f-name").value.trim()
    };
  }
  function validate(o) {
    if (!(o.y >= 1900 && o.y <= 2100)) return "태어난 해는 1900~2100년 사이로 입력해 주세요.";
    if (!(o.m >= 1 && o.m <= 12)) return "태어난 달은 1~12 사이로 입력해 주세요.";
    var maxD = o.calendar === "lunar" ? S.lunarMonthLen(o.y, o.m, o.leap) : new Date(o.y, o.m, 0).getDate();
    if (o.calendar === "lunar" && o.y > 2050) return "음력 변환은 2050년까지 지원합니다. 양력으로 입력해 주세요.";
    if (o.calendar === "lunar" && o.leap && !S.hasLeap(o.y, o.m)) return o.y + "년에는 윤" + o.m + "월이 없습니다. 윤달 체크를 해제해 주세요.";
    if (!(o.d >= 1 && o.d <= maxD)) return "태어난 날은 1~" + maxD + " 사이로 입력해 주세요.";
    if (o.hour !== null && !(o.hour >= 0 && o.hour <= 23)) return "태어난 시는 0~23 사이로 입력해 주세요.";
    if (o.minute < 0 || o.minute > 59) return "태어난 분은 0~59 사이로 입력해 주세요.";
    return "";
  }

  function run(push) {
    var o = readOpts(), err = validate(o), box = $("form-error");
    if (err) { box.textContent = err; box.classList.add("show"); return; }
    box.classList.remove("show");
    var r;
    try { r = S.calc(o); } catch (e) { box.textContent = e.message; box.classList.add("show"); return; }
    render(r, o);
    if (push) {
      var q = new URLSearchParams({ c: o.calendar, y: o.y, m: o.m, d: o.d, g: o.gender, ja: o.jaSi, cor: o.correction ? 1 : 0, dst: o.dst ? 1 : 0 });
      if (o.leap) q.set("leap", 1);
      if (o.hour !== null) { q.set("h", o.hour); q.set("mi", o.minute); } else q.set("h", "");
      if (o.name) q.set("n", o.name);
      history.replaceState(null, "", "?" + q.toString());
    }
    $("result").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  /* ---------- 렌더 ---------- */
  function render(r, o) {
    var P = r.pillars, c = r.cols, ds = P.day.stem;
    var html = [];
    var title = (o.name ? esc(o.name) + "님의 " : "") + "사주 명식";
    var inputTxt = (o.calendar === "lunar" ? "음력 " + o.y + "년 " + o.m + "월 " + o.d + "일" + (o.leap ? "(윤달)" : "") + " → 양력 " : "양력 ") + r.solar.y + "년 " + r.solar.m + "월 " + r.solar.d + "일 " + (r.hasTime ? pad2(o.hour) + ":" + pad2(o.minute) : "(시간 모름)") + " · " + (o.gender === "M" ? "남성" : "여성");
    var lunarTxt = r.lunar && o.calendar !== "lunar" ? "음력 " + r.lunar.y + "년 " + (r.lunar.leap ? "윤" : "") + r.lunar.m + "월 " + r.lunar.d + "일" : "";

    html.push('<section class="section"><div class="card">');
    html.push('<h2 class="serif" style="margin:0 0 4px">' + title + '</h2>');
    html.push('<div class="hint">' + inputTxt + (lunarTxt ? " · " + lunarTxt : "") + " · " + S.ANIMALS[P.year.branch] + "띠</div>");
    // 안내 알림
    var notes = [];
    if (r.meta.dstApplied) notes.push("출생일은 서머타임 시행 기간이어서 1시간을 빼고 계산했습니다.");
    if (r.meta.corrected) notes.push("표준시 −30분 보정을 적용해 " + r.meta.usedDate + " " + r.meta.usedClock + " 기준으로 계산했습니다.");
    if (r.meta.baseOffset !== 540) notes.push("출생 당시 한국 표준시(" + (r.meta.baseOffset === 510 ? "동경 127.5도, UTC+8:30" : "지방평균시") + ")를 반영했습니다.");
    if (r.meta.nearTerm && r.meta.nearTermMinutes < 180) notes.push(r.meta.nearTerm.name + " 절입 시각(" + S.fmtKst(r.meta.nearTerm.t) + ")과 " + r.meta.nearTermMinutes + "분 차이입니다. 출생 시각이 정확한지 한 번 더 확인해 주세요.");
    if (r.meta.lateZa) notes.push("밤 11시대 출생이라 자시 설정(" + (o.jaSi === "ya" ? "야자시: 일주는 당일 유지" : "조자시: 23시부터 다음 날 일주") + ")에 따라 일주가 달라질 수 있습니다.");
    if (r.hasTime && !o.correction) {
      var alt = S.calc(Object.assign({}, o, { correction: true }));
      if (alt.pillars.hour && (alt.pillars.hour.stem !== P.hour.stem || alt.pillars.hour.branch !== P.hour.branch || alt.pillars.day.stem !== P.day.stem || alt.pillars.month.branch !== P.month.branch))
        notes.push("고급 설정의 ‘표준시 −30분 보정’을 켜면 시주(또는 일·월주)가 달라집니다. 어느 쪽을 쓸지는 <a href=\"/saju/method.html#time\">계산 기준</a>을 참고해 주세요.");
    }
    notes.forEach(function (n) { html.push('<div class="notice">' + n + "</div>"); });

    // 명식표
    html.push('<table class="pillars"><thead><tr><th></th>' + KEYS.map(function (k) { return '<th class="' + (k === "day" ? "me" : "") + '">' + KEY_NAME[k] + (k === "day" ? " (나)" : "") + "</th>"; }).join("") + "</tr></thead><tbody>");
    html.push("<tr><td class=\"label\">천간 십성</td>" + KEYS.map(function (k) { var col = c[k]; return "<td class=\"god\">" + (!col ? "-" : k === "day" ? "일간" : T.god[col.stemGod].name) + "</td>"; }).join("") + "</tr>");
    html.push("<tr><td class=\"label\">천간</td>" + KEYS.map(function (k) { return c[k] ? stemCell(c[k].stem, k === "day" ? " me" : "") : '<td class="glyph el-3"><span class="h">?</span><span class="k">모름</span></td>'; }).join("") + "</tr>");
    html.push("<tr><td class=\"label\">지지</td>" + KEYS.map(function (k) { return c[k] ? branchCell(c[k].branch) : '<td class="glyph el-3"><span class="h">?</span><span class="k">모름</span></td>'; }).join("") + "</tr>");
    html.push("<tr><td class=\"label\">지지 십성</td>" + KEYS.map(function (k) { return "<td class=\"god\">" + (c[k] ? T.god[c[k].branchGod].name : "-") + "</td>"; }).join("") + "</tr>");
    html.push("<tr><td class=\"label\">지장간</td>" + KEYS.map(function (k) {
      return "<td>" + (c[k] ? '<div class="hid">' + c[k].hidden.map(function (h) { return '<span class="' + elc(S.STEM_EL[h.stem]) + '" title="' + T.god[h.god].name + '">' + S.STEMS[h.stem] + "</span>"; }).join("") + "</div>" : "-") + "</td>";
    }).join("") + "</tr>");
    html.push("<tr><td class=\"label\">십이운성</td>" + KEYS.map(function (k) { return "<td>" + (c[k] ? S.STAGES[c[k].stage] : "-") + "</td>"; }).join("") + "</tr>");
    html.push("</tbody></table>");
    html.push('<p class="table-note">글자 색은 오행입니다. <span class="chip el el-0"><i class="dot"></i>목</span> <span class="chip el el-1"><i class="dot"></i>화</span> <span class="chip el el-2"><i class="dot"></i>토</span> <span class="chip el el-3"><i class="dot"></i>금</span> <span class="chip el el-4"><i class="dot"></i>수</span> · 지장간 위에 마우스를 올리면 십성이 보입니다. 공망: ' + r.gongmang.map(function (b) { return S.BRANCHES[b] + "(" + S.BRANCHES_H[b] + ")"; }).join(", ") + "</p>");
    html.push("</div></section>");

    // 한눈에 보기
    var dsT = T.dayStem[ds], dsE = S.STEM_EL[ds];
    html.push('<section class="section"><h2>한눈에 보기 <small>나를 한 장면으로</small></h2><div class="grid2">');
    html.push('<div class="card"><div class="daystem ' + elc(dsE) + '"><div class="bigchar">' + S.STEMS_H[ds] + '</div><div><div class="tagline">' + dsT.tag + "</div><h3>" + dsT.name + " · " + dsT.image + "</h3><p style=\"margin:6px 0 0\">" + dsT.body + '</p></div></div><div class="plusminus"><div><b class="tag-good">👍 강점</b> ' + dsT.good + '</div><div><b class="tag-care">⚠️ 조심할 점</b> ' + dsT.care + "</div></div></div>");
    // 강약
    var pos = Math.max(4, Math.min(96, r.strength.ratio * 100));
    html.push('<div class="card"><h3 style="margin:0 0 4px">힘의 균형 <span class="pill">' + r.strength.label + '</span></h3><div class="meter"><i style="left:' + pos + '%"></i></div><div class="meter-labels"><span>신약(내 힘이 약함)</span><span>신강(내 힘이 강함)</span></div>');
    html.push('<p style="margin:10px 0 6px">' + T.strength[r.strength.label] + "</p>");
    html.push('<div><span class="pill ' + (r.strength.deukRyeong ? "ok" : "") + '">득령 ' + (r.strength.deukRyeong ? "○" : "×") + '</span><span class="pill ' + (r.strength.deukJi ? "ok" : "") + '">득지 ' + (r.strength.deukJi ? "○" : "×") + '</span><span class="pill ' + (r.strength.deukSe ? "ok" : "") + '">득세 ' + (r.strength.deukSe ? "○" : "×") + "</span></div>");
    html.push('<p class="hint" style="margin:8px 0 0">나를 돕는 힘(비겁·인성) 비중 ' + pct(r.strength.ratio * 100) + " · 월지에 1.5배의 무게를 두어 계산한 참고 지표입니다.</p></div>");
    html.push("</div>");
    // 도움 되는 기운
    html.push('<div class="card" style="margin-top:16px"><h3 style="margin:0 0 8px">균형을 맞춰 주는 기운 <span class="hint">(참고)</span></h3><div class="row-inline">' + r.helpers.elements.map(function (e) { return '<span class="chip el ' + elc(e) + '"><i class="dot"></i>' + T.element[e].name + " · " + T.element[e].color + "</span>"; }).join("") + "</div>" + (r.helpers.note ? '<p style="margin:10px 0 0">' + r.helpers.note + "</p>" : "") + '<p class="hint" style="margin:8px 0 0">억부(강약)와 조후(계절)를 단순화한 참고용 결과입니다. 정밀한 용신은 격국과 대운 흐름까지 함께 보아야 하므로, 일상 팁으로만 활용해 주세요.</p></div>');
    html.push("</section>");

    // 오행
    var sorted = r.elements.slice().sort(function (a, b) { return b.pct - a.pct; });
    var top = sorted[0], low = sorted[sorted.length - 1];
    html.push('<section class="section"><h2>오행 분포 <small>목·화·토·금·수의 균형</small></h2><div class="card"><div class="bars">' + r.elements.map(function (e) {
      return '<div class="bar ' + elc(e.idx) + '"><span class="lbl"><i class="dot"></i>' + e.name + "(" + e.hanja + ')</span><span class="track"><span class="fill" style="display:block;width:' + Math.min(100, e.pct * 2) + '%"></span></span><span class="val">' + pct(e.pct) + "</span></div>";
    }).join("") + "</div>");
    html.push('<div class="talk" style="margin-top:12px"><p><b>가장 강한 기운: ' + T.element[top.idx].name + "</b> — " + T.element[top.idx].many + "</p><p><b>가장 약한 기운: " + T.element[low.idx].name + "</b> — " + T.element[low.idx].few + "</p></div>");
    html.push('<p class="hint">천간 1점, 지지는 속에 든 지장간을 일수 비율로 나누어 합산하고 월지에는 1.5배를 주었습니다. 겉으로 보이는 8글자 기준 개수: ' + r.elements.map(function (e) { return e.name + " " + e.count8; }).join(" · ") + "</p></div></section>");

    // 십성
    html.push('<section class="section"><h2>십성 분포 <small>내가 세상과 만나는 방식</small></h2><div class="card"><div class="bars">' + r.groups.map(function (g) {
      return '<div class="bar group"><span class="lbl">' + g.name + '</span><span class="track"><span class="fill" style="display:block;width:' + Math.min(100, g.pct * 2) + '%"></span></span><span class="val">' + pct(g.pct) + "</span></div>";
    }).join("") + "</div>");
    var gs = r.groups.slice().sort(function (a, b) { return b.pct - a.pct; });
    html.push('<div class="talk" style="margin-top:12px">');
    html.push("<p><b>" + gs[0].name + " (" + T.group[gs[0].name].label + ") 이 두드러집니다.</b> " + T.group[gs[0].name].strong + "</p>");
    var lowG = gs[gs.length - 1];
    html.push("<p><b>" + lowG.name + " (" + T.group[lowG.name].label + ") 은 약한 편입니다.</b> " + (lowG.pct < 4 ? T.group[lowG.name].none : T.group[lowG.name].weak) + "</p></div>");
    html.push('<details style="margin-top:8px"><summary class="hint" style="cursor:pointer">열 가지 십성 쉬운 설명 보기</summary><ul class="clean" style="margin-top:8px">' + T.god.map(function (g, i) { return "<li><b>" + g.name + "</b>" + g.easy + '<br><span class="hint">' + g.area + " · 내 사주 비중 " + pct(r.godScore[i] / (r.groups.reduce(function (a, b) { return a + b.score; }, 0) || 1) * 100) + "</span></li>"; }).join("") + "</ul></details>");
    html.push("</div></section>");

    // 합충형해
    html.push('<section class="section"><h2>합·충·형·해 <small>글자끼리의 관계</small></h2><div class="card">');
    if (!r.relations.length) html.push("<p style=\"margin:0\">네 기둥 사이에 두드러진 합·충·형·해가 없는 안정된 구성입니다.</p>");
    else html.push('<ul class="clean">' + r.relations.map(function (x) {
      var good = /합/.test(x.type), cls = good ? "good" : "bad";
      return '<li><span class="rel-tag ' + cls + '">' + x.type + "</span><b>" + x.text + "</b><br><span class=\"hint\">" + (T.relation[x.type] || "") + "</span></li>";
    }).join("") + "</ul>");
    html.push("</div></section>");

    // 신살
    html.push('<section class="section"><h2>신살 <small>특별한 기운의 표식</small></h2><div class="card">');
    if (!r.sinsal.length) html.push('<p style="margin:0">두드러진 신살이 없습니다.</p>');
    else html.push('<ul class="clean">' + r.sinsal.map(function (x) { return "<li><b>" + x.name + "</b> <span class=\"pill\">" + esc(x.where.join(", ")) + "</span><br><span class=\"hint\">" + (T.sinsal[x.name] || "") + "</span></li>"; }).join("") + "</ul>");
    html.push('<p class="hint" style="margin:10px 0 0">신살은 학파마다 기준이 조금씩 다릅니다. 이 사이트는 널리 쓰이는 기준만 표시하며, 좋고 나쁨을 단정하기보다 성향의 힌트로 읽어 주세요.</p></div></section>');

    // 대운
    var nowD = new Date(), ageNow = (nowD - Date.UTC(r.solar.y, r.solar.m - 1, r.solar.d) + 0) / 31556926000 - 0;
    var curIdx = Math.floor((ageNow - r.luck.exactYears) / 10);
    if (curIdx > 9) curIdx = 9;
    html.push('<section class="section"><h2>대운 <small>10년 단위의 큰 흐름 · ' + (r.luck.forward ? "순행" : "역행") + " · " + r.luck.startAge + '세부터</small></h2><div class="card">');
    html.push('<div class="luck-scroll" id="luck-scroll">' + r.luck.list.map(function (l, i) {
      var e = S.STEM_EL[l.stem], b = S.BRANCH_EL[l.branch];
      return '<button type="button" class="luck' + (i === curIdx ? " now" : "") + '" data-i="' + i + '"><div class="age">' + l.age + "세</div><div class=\"pair\"><span class=\"" + elc(e) + "\">" + S.STEMS_H[l.stem] + "</span><span class=\"" + elc(b) + "\">" + S.BRANCHES_H[l.branch] + "</span></div><div class=\"g\">" + T.god[l.stemGod].name + "</div><div class=\"age\">" + l.year + "~</div></button>";
    }).join("") + "</div>");
    html.push('<div id="luck-detail" class="talk"></div>');
    html.push('<p class="hint">대운수는 태어난 날부터 앞(순행)·뒤(역행) 절기까지 일수를 3으로 나눈 값입니다(' + (r.luck.forward ? "다음" : "지난") + " 절기 " + (r.luck.forward ? r.meta.nextJie.name + " " + r.meta.nextJie.at : r.meta.prevJie.name + " " + r.meta.prevJie.at) + ").</p></div></section>");

    // 세운
    var cy = nowD.getFullYear();
    var yl = S.yearLuck(r, cy - 2, cy + 7);
    html.push('<section class="section"><h2>세운 <small>해마다의 흐름</small></h2><div class="card"><div style="overflow-x:auto"><table class="year-table"><thead><tr><th>연도</th><th>나이</th><th>간지</th><th>십성</th><th>12운성</th></tr></thead><tbody>' + yl.map(function (y) {
      return '<tr class="' + (y.year === cy ? "now" : "") + '"><td>' + y.year + (y.year === cy ? " (올해)" : "") + "</td><td>" + y.age + "세</td><td>" + mini(y.stem, y.branch) + "</td><td>" + T.god[y.stemGod].name + " / " + T.god[y.branchGod].name + "</td><td>" + S.STAGES[y.stage] + "</td></tr>";
    }).join("") + "</tbody></table></div>");
    var thisY = yl.filter(function (y) { return y.year === cy; })[0];
    if (thisY) html.push('<div class="talk" style="margin-top:10px"><p><b>' + cy + "년 (" + S.STEMS[thisY.stem] + S.BRANCHES[thisY.branch] + ") 올해의 키워드: " + T.god[thisY.stemGod].name + "</b><br>" + T.luckGod[thisY.stemGod] + "</p></div>");
    html.push("</div></section>");

    html.push('<div class="disclaimer">' + T.disclaimer + ' 계산 방식과 출처는 <a href="/saju/method.html">계산 기준과 한계</a>에서 확인할 수 있어요.</div>');
    html.push('<div class="row-inline" style="margin-top:14px"><button class="btn sub" id="btn-share" type="button">🔗 결과 주소 복사</button><button class="btn sub" id="btn-print" type="button">🖨️ 인쇄/PDF 저장</button></div>');

    var box = $("result");
    box.innerHTML = html.join("");
    box.classList.remove("hidden");
    $("btn-share").addEventListener("click", function () { $("f-share").click(); });
    $("btn-print").addEventListener("click", function () { window.print(); });
    var lucks = box.querySelectorAll(".luck");
    function showLuck(i) {
      i = Math.max(0, i);
      lucks.forEach(function (b) { b.classList.toggle("sel", +b.dataset.i === i); });
      var l = r.luck.list[i];
      $("luck-detail").innerHTML = "<p><b>" + l.age + "세 ~ " + (l.age + 9) + "세 (" + S.STEMS[l.stem] + S.BRANCHES[l.branch] + " 대운) · " + T.god[l.stemGod].name + "</b><br>" + T.luckGod[l.stemGod] + "</p><p class=\"hint\">지지의 십성은 " + T.god[l.branchGod].name + ", 일간 기준 12운성은 " + S.STAGES[l.stage] + "입니다.</p>";
    }
    lucks.forEach(function (b) { b.addEventListener("click", function () { showLuck(+b.dataset.i); }); });
    showLuck(curIdx < 0 ? 0 : curIdx);
    if (curIdx >= 0) { var sc = $("luck-scroll"), cur = lucks[curIdx]; if (sc && cur) sc.scrollLeft = Math.max(0, cur.offsetLeft - 16); }
    if (curIdx < 0) $("luck-detail").insertAdjacentHTML("afterbegin", '<div class="notice">아직 첫 대운이 시작되기 전입니다. 만 ' + r.luck.exactYears.toFixed(1) + "세 무렵부터 첫 대운이 열립니다.</div>");
  }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }

  /* ---------- 테마 ---------- */
  function initTheme() {
    var saved = null; try { saved = localStorage.getItem("saju-theme"); } catch (e) {}
    var theme = saved || (window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    document.documentElement.setAttribute("data-theme", theme);
    var b = $("theme-btn"); if (!b) return;
    b.textContent = theme === "dark" ? "☀️" : "🌙";
    b.addEventListener("click", function () {
      var t = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", t); b.textContent = t === "dark" ? "☀️" : "🌙";
      try { localStorage.setItem("saju-theme", t); } catch (e) {}
    });
  }
  window.SajuTheme = initTheme;

  initTheme();
  if (form) initForm();
})();
