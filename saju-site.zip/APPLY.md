# 느릿느릿 사주풀이 — 적용 방법 (TurtleKing 저장소)

1. zip 안의 파일을 저장소 루트에 그대로 덮어쓰기 (index.html, lotto/index.html, saju/*, 기존 페이지 링크 수정분, data/scripts 2개, sitemaps/pages.xml)
   - 기존 로또 메인(index.html)은 lotto/index.html 로 옮겨져 있습니다.
2. 로또 회차/번호 페이지의 "돌아가기" 링크 갱신:  python3 data/scripts/generate_kr645_pages.py
3. 확인 후 커밋·푸시 → Cloudflare 자동 배포
